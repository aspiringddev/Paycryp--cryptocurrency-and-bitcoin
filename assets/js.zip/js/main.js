$(document).ready(function(){

    $('#hero-section').fuwatto({
        duration: 2000,
        slide:'bottom-top',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },

      });
      $('.service-cards').fuwatto({
        duration: 2000,
        slide:'right-left',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },
      });
      $('.about-left').fuwatto({ 
        duration: 2000,
        slide:'left-right',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },
      });
      $('.about-right').fuwatto({ 
        duration: 2000,
        slide:'right-left',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },
      });

      $('.gs-card-wrapper').fuwatto({ 
        duration: 2000,
        slide:'bottom-top',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },
      });
    //   testimonial
      $('.sc-left').fuwatto({ 
        duration: 2000,
        slide:'left-right',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },
      });
      $('.sc-right').fuwatto({ 
        duration: 2000,
        slide:'right-left',
        distance: 600,
      });
    //   latest news
    $('.ln-left').fuwatto({ 
        duration: 2000,
        slide:'left-right',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },
      });
      $('.ln-right').fuwatto({ 
        duration: 2000,
        slide:'right-left',
        distance: 600,
        adjustment: {
            top: 0,
            left: 0,
          },
      });
  });